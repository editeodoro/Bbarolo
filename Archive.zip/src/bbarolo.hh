#ifndef BAROLO_HH
#define BAROLO_HH


#define ruint register unsigned int


#endif
