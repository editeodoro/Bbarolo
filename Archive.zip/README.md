# Bbarolo
Bbarolo is a 3D fitting tool to derive the kinematics of galaxies from emission-line observations.
